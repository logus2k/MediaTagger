namespace Spectre.Console;

internal static class Constants
{
    public const int DefaultTerminalWidth = 80;
    public const int DefaultTerminalHeight = 24;

    public const string EmptyLink = "https://emptylink";
}