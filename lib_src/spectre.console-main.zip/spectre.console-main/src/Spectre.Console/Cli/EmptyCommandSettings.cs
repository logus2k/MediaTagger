namespace Spectre.Console.Cli;

/// <summary>
/// Represents empty settings.
/// </summary>
public sealed class EmptyCommandSettings : CommandSettings
{
}