Title: Short title, less than 50 characters
Description: Longer description, with optional *bold* and **italic** characters. Shouldn't be TOO long but can span multiple lines.
Published: 20210710
Category: Release Notes | News | or whatever
Excluded: true
---

Intro paragraph, maybe even just the description. No need for a title that's included automatically.

## Use second level headers

Main title will be set with h1

## Tasks

1. Set title and description
2. Set proper publish date
3. Set proper category
4. Remove excluded attribute.