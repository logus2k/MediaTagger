namespace Spectre.Console;

internal enum MarkupTokenKind
{
    Text = 0,
    Open,
    Close,
}