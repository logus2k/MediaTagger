namespace Spectre.Console.Cli;

internal enum ParsingMode
{
    Relaxed = 0,
    Strict = 1,
}