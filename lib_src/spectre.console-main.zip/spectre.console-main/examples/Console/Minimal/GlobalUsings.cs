global using Spectre.Console;
global using static Spectre.Console.AnsiConsole;