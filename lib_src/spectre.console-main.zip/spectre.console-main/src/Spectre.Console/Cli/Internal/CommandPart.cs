namespace Spectre.Console.Cli;

internal enum CommandPart
{
    CommandName,
    LongOption,
}