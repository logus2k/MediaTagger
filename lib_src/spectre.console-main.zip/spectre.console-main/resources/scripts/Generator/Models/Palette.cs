namespace Generator.Models
{
    public sealed class Palette
    {
    }
}
